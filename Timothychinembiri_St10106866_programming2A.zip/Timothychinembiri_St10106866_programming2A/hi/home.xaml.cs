﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for home.xaml
    /// </summary>
    public partial class home : Window
    {
        public home()
        {
            InitializeComponent();
        }
		public static  List<double> homes = new List<double>(1);
		public static double sup, mbb, repps;
		public static FlowDocument flowDocument3 = new FlowDocument();
		public static Paragraph paragraph3 = new Paragraph();

		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }

		private void homeprocess(object sender, RoutedEventArgs e)
		{
			String purchaseamount = homeamount.Text.ToString();
			double pu = Convert.ToDouble(purchaseamount);
			String depositamount = homedeposit.Text.ToString();
			double deposit = Convert.ToDouble(depositamount);
			double amount = pu - deposit;

			String interestamount = homeinterest.Text.ToString();
			double interest = Convert.ToDouble(interestamount);
			double summ = interest / (12 * 100);
			String yearsa = yearsamount.Text.ToString();
			double year = Convert.ToDouble(yearsa);


			double remain = amount;

			double rep = (remain * summ * (double)Math.Pow(1 + summ, year))
			/ (double)(Math.Pow(1 + summ, year) - 1);
			repps += rep;
			homes.Add(repps);
			mbb = budget.expense - homes[0];

			sup = Launch.a.GetIncome() * 0.33333333333;
			if (homes[0] > sup)
			{
				Disqualified disqualified = new Disqualified();
				disqualified.ShowDialog();
				this.Close();
			}
			else
			{
				Qualified qualified = new Qualified();
				qualified.ShowDialog();
				

			}
		}
			private void homeclearbtn(object sender, RoutedEventArgs e)
        {
			richtextbox3.Document.Blocks.Clear();

		}

        private void homeviewbtn(object sender, RoutedEventArgs e)
        {
			

			
			paragraph3.Inlines.Add("---------------------------------------------------\n ~~Monthly Expenditure Invoice for all Expenses~~\n" +
					  "---------------------------------------------------\n" +
			"(Income after Tax) R " + Launch.Aftertaxincome +
		"\n (Grocery amount for this month was) -R " + budget.expenses[0] +
		"\n (Water and lights amount for this month was) -R " + budget.expenses[1] +
		"\n (Traveling Costs(Including Petrol) amount for this month was) -R " + budget.expenses[2] +
		"\n (Cellphone and Tellphone amount for this month was) -R " + budget.expenses[3] +
		"\n (other amount for this month was) -R " + budget.expenses[4] + "\n*******" +
		"\n  (Home loan repayment for this month was) R " + Math.Round(homes[0], 2) + "\n*******" +
		"\n(Remaining bank balance after  all deductions) : R" + Math.Round(mbb, 2));
			flowDocument3.Blocks.Add(paragraph3);
			richtextbox3.Document = flowDocument3;

		}

		private void homenextbtn(object sender, RoutedEventArgs e)
        {
			vehicle vehicle = new vehicle();
			
			vehicle.rebalance.Text = Convert.ToString(Math.Round(mbb, 2));
     		vehicle.Show();
			this.Close();
        }

        private void richtextbox3_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }
    }
}
