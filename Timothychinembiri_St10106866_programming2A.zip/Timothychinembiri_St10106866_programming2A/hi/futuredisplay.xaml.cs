﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for futuredisplay.xaml
    /// </summary>
    public partial class futuredisplay : Window
    {
        public futuredisplay()
        {
            InitializeComponent();
        }
        //VARIABLES GLOBAL
        public static FlowDocument flowDocument6 = new FlowDocument();
        public static Paragraph paragraph6 = new Paragraph();
        public static double inte, yea, futures,  pricing;
    
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
        //Button CALL
        private void endedbtn(object sender, RoutedEventArgs e)
        {
            Account account = new Account();
            account.Show();
            this.Close();
            
          
        }

        private void resetbtnfuture(object sender, RoutedEventArgs e)
        {
            interestbl.Clear();
            prices.Clear();
           
        }

        private void richtextbox6_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }

        private void richtextbox3_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }

        private void viewfuture(object sender, RoutedEventArgs e)
        {
            methoding();
            paragraph6.Inlines.Add("\n---------------------------------------------------\n\n Future Investment\n\n" +
                               "---------------------------------------------------\n\n" +
                               "Reason For Investment R " + reason.Text.ToString() +
     "\n\n Amount desired to save R  " + pricing +
     "\n\n Interest Rate:  " + interestbl.Text.ToString() +
     "\n\n Amount of years: " + yearsamout.Text.ToString() +
     "\n\n---------------------------------------------------" +
     "\n\n R" + futures+" is the amount to pay for the next " + yea +  " months to achieve \n" + prices.Text.ToString()+ " for " + reason.Text.ToString()+
     
     "\n\n---------------------------------------------------");
            flowDocument6.Blocks.Add(paragraph6);
            richtextbox6.Document = flowDocument6;

        }
        public void methoding() {
           pricing = Convert.ToDouble(prices.Text.ToString());
            inte = Convert.ToDouble(interestbl.Text.ToString());
            yea= Convert.ToDouble(yearsamout.Text.ToString());
            inte = inte / 100;
            yea = yea * 12;
             futures = (pricing * inte) / yea;


        }
    }
}
