﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for rent.xaml
    /// </summary>
    public partial class rent : Window
    {
        public rent()
        {
            InitializeComponent();
        }
        public static  List<double> loan = new List<double>(1);
        public static double bb;
        public static FlowDocument flowDocument2 = new FlowDocument();
        public static Paragraph paragraph2 = new Paragraph();
       

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }

       

        private void rentclearbtn(object sender, RoutedEventArgs e)
        {
            richtextbox2.Document.Blocks.Clear();

        }

        private void rentprocess(object sender, RoutedEventArgs e)
        {
            
           string rent =  rentblock.Text.ToString();
           double ren= Convert.ToDouble(rent);
            loan.Add(ren);
             bb = budget.expense - loan[0];
          
            if (bb < 0)
            {
               
                Disqualified disqualified = new Disqualified();
                disqualified.ShowDialog();
                this.Close();
            }
            else
            {
                Qualified qualified = new Qualified();
                qualified.ShowDialog();
                
              
            }
        }
        abstract class Expense
        {


            protected abstract void Rent();

        }
        private void rentviewbtn(object sender, RoutedEventArgs e)
        {

            paragraph2.Inlines.Add("---------------------------------------------------\n~~~~ Monthly Expenditure Invoice for all Expenses~~~~\n" +
                           "---------------------------------------------------\n" +
                 "(Income after Tax) R " + Launch.Aftertaxincome +
 "\n (Grocery amount for this month was) -R " + budget.expenses[0] +
 "\n (Water and lights amount for this month was) -R " + budget.expenses[1] +
 "\n (Traveling Costs(Including Petrol) amount for this month was) -R " + budget.expenses[2] +
 "\n (Cellphone and Tellphone amount for this month was) -R " + budget.expenses[3] +
 "\n (other amount for this month was) -R " + budget.expenses[4] + "\n*******" +
 "\n  (Rent repayment for this month was) R " + Math.Round(loan[0], 2) + "\n*******" +
 "\n(Remaining bank balance after  all deductions) : R" + Math.Round(bb, 2));
            flowDocument2.Blocks.Add(paragraph2);
            richtextbox2.Document = flowDocument2;
        }
        private void rentnextbtn(object sender, RoutedEventArgs e)
        {
            vehicle vehicle = new vehicle();
            vehicle.rebalance.Text = Convert.ToString(bb);
            vehicle.Show();
            this.Close();
        }

        private void richtextbox2_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }
    }
}
