﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for vehicle.xaml
    /// </summary>
    public partial class vehicle : Window
    {
        public vehicle()
        {
            InitializeComponent();
            combobx.Items.Add(new ComboBoxItem() { Content = "Suv Selection" });
            combobx.Items.Add(new ComboBoxItem() { Content = "Commercial Cars Selection" });
            combobx.Items.Add(new ComboBoxItem() { Content = "Bike Selection" });
            combobx.Items.Add(new ComboBoxItem() { Content = "Sport Cars Selection" });
            combobx.Items.Add(new ComboBoxItem() { Content = "Other Selection" });
        }
        
        //declaring varaibles
        public static double deposit, price, premium, amount, payment, rate;
        //instanciating time variable
        public static DateTime dateTimes = DateTime.Now;
        
        //declaring array lists
        public static List<string> makes = new List<string>();
        public static List<string> models = new List<string>();
        public static List<double> deposits = new List<double>();
        public static List<double> prices = new List<double>();
        public static List<double> Calculator = new List<double>();
        public static List<double> premiums = new List<double>();
        public static  List<double> rates = new List<double>();
        public static double sumforcalulator = 0;
        
        //COMBOBOX
        private void combobx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            selectedcar.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
        }

        private void vehiclebtn(object sender, RoutedEventArgs e)
        {
            vehiclemethod();
            Calculations();
           
        }
        public void vehiclemethod() {
            try
            {

                models.Add(modelbox.Text.ToString());
                makes.Add(makebox.Text.ToString());
                price = Convert.ToDouble(pricebox.Text.ToString());
                prices.Add(price);
                deposit = Convert.ToDouble(depositbox.Text.ToString());
                deposits.Add(deposit);
                budget.dic_.Add(deposits[0], "Car Deposit");
                double ans = Convert.ToDouble(interestbox.Text.ToString());
                rate = ans / 100;
                rates.Add(rate);
                premium = Convert.ToDouble(insurancebox.Text.ToString());
                premiums.Add(premium);
                budget.dic_.Add(premiums[0], "Insurance");
            }
            catch (Exception g)
            {
                Console.WriteLine(g.Message);
                Console.ReadLine();
                throw;
            }
        }
        public void Calculations()
        {
            double sum = 0, sumforexpense = 0, sumforsummary = 0, sums = 0, sumforpre = 0, sumsfordeposit = 0, sumforhome = 0;
            const int years = 5;
            //for each for lists
            foreach (var i in prices)
            {
                sum = +i;


            }
            foreach (var i in premiums)
            {
                sumforpre = +i;

            }
            foreach (var i in rates)
            {
                sums = +i / (12 * 100);

            }
            foreach (var i in deposits)
            {
                sumsfordeposit = +i;

            }
            foreach (var i in rent.loan)
            {
                sumforsummary = +i;

            }
            foreach (var i in home.homes)
            {
                sumforhome = +i;

            }
            foreach (var i in budget.expenses)
            {
                sumforexpense = +i;

            }
            sumforcalulator = sumforexpense + sumforsummary + sumforhome + deposits[0] + premiums[0];
            double summe = sumforsummary + sumforhome;
            budget.dic_.Add(summe, "Home Expense");
            int amount = years * 12;
            double remain = sum - sumsfordeposit;
            payment = ((remain * sums * (double)Math.Pow(1 + sums, amount))
            / (double)(Math.Pow(1 + sums, amount) - 1)) + sumforpre;


            payment += (sumforsummary + sumforhome);
            double desicion = Launch.a.GetIncome() * 0.75;

            Math.Round(desicion, 2);

            if (payment >= desicion)
            {
                Disqualified disqualified = new Disqualified();
                disqualified.ShowDialog();
                this.Hide();

            }
            else
            {
                Qualified qualified = new Qualified();
                qualified.ShowDialog();
                this.Hide();
                Window2 window2 = new Window2();
                window2.Show();
                this.Close();
             

            }
        }

            private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }


       
    }
}
