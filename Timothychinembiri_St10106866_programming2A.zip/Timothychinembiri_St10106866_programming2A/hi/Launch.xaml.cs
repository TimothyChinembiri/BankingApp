﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for Launch.xaml
    /// </summary>
    public partial class Launch : Window
    {
        public Launch()
        {
            InitializeComponent();
            cmbbox.Items.Add(new ComboBoxItem() { Content = "R" });
            
            
         

        }
        public static Launch launch = new Launch();
        public static budget budget = new budget();
        public static  rent rent = new rent();
        public static Get a = new Get();
        public static double Aftertaxincome;
        private void cmbbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
            
        {
            launch.curr.Text  = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            launch.curren.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.chosen.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.symbol1.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.symbol2.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.symbol3.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.symbol4.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            budget.symbol5.Text = ((ComboBoxItem)(((ComboBox)sender).SelectedItem)).Content.ToString();
            
        }

        private void launchback(object sender, RoutedEventArgs e)
        {
            Account account = new Account();
            account.Show();
            this.Close();
        }

    

        private void calculatebt(object sender, RoutedEventArgs e)
             
        {
           

        method();
            launch.Show();
            this.Hide();

        }
        private void method() {
            
            launch.BeforeTax.Text = incomeblock.Text.ToString();
            double sa = Convert.ToDouble(incomeblock.Text.ToString());
            a.SetIncome(sa);
            String ta = taxblock.Text.ToString();
            double taxamoun = Convert.ToDouble(ta);
            double taxes = taxamoun / 100;
            double taxcalu = a.GetIncome() * taxes;
            Aftertaxincome = a.GetIncome() - taxcalu;
            Math.Round(Aftertaxincome, 2);
            launch.afterTax.Text = Convert.ToString(Aftertaxincome);
            budget.balan.Text = Convert.ToString(Aftertaxincome);
        }
        private void next(object sender, RoutedEventArgs e)
        {
          
           
            message message = new message();
            message.ShowDialog();
            this.Hide();
            method();
            budget.Show();
            this.Close();
        }
        //getters and setter
        public class Get
        {
            private double income;
            public double GetIncome()
            {
                return income;
            }
            public void SetIncome(double value)
            {
                income = value;
            }


        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
    }
}
