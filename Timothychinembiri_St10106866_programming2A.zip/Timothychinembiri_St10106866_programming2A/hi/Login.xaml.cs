﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Register reg = new Register();
            reg.Show();
            this.Close();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            String userpass = "Thelma";
            String username = "Timothy";
            String userinputtext= Textbox1.Text.ToString();
            String passwordinputtext = Passwordbox1.Password.ToString();
           
                if ((userinputtext.Equals(username) && passwordinputtext.Equals(userpass)))
                {
                    Account acc = new Account();
                    MessageBox.Show("Welcome back, Timothy Chinembiri. \nReady to Bank smart.");
                    acc.TextName.Text = Globals.userinputname;
                    acc.ShowDialog();
                    this.Close();


                }

                else
                {
                    MessageBox.Show("Either your password or username is wrong./nPlease try again:(");
                    Textbox1.Clear();
                    Passwordbox1.Clear();

                }
            
            
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
    }
}
