﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for review.xaml
    /// </summary>
    public partial class review : Window
    {
        public review()
        {
            InitializeComponent();
        }
        public static FlowDocument flowDocument = new FlowDocument();
        public static Paragraph paragraph = new Paragraph();
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }

        }

        private void returnbtn(object sender, RoutedEventArgs e)
        {
            budget budget = new budget();
            budget.Show();
            this.Close();
        }

        private void nextbtn(object sender, RoutedEventArgs e)
        {
          loans loans = new loans();          
            loans.ShowDialog();
            this.Hide();
        }

        private void viewbtn(object sender, RoutedEventArgs e)
        {
            if (grocbtn.IsChecked == true)
            {
                

                paragraph.Inlines.Add("\n---------------------------------------------------\n\nMonthly Expenditure Invoice for Groceries\n\n" +

                                                          "---------------------------------------------------\n\n" + "(Income after Tax) R " + Launch.Aftertaxincome +
                        "\n\n (Grocery amount for this month was) -R " + budget.expenses[0] + "\n\n---------------------------------------------------" +
                        "\n\n (Remaining income amount after Groceries expense) R " + budget.groceries + "\n\n---------------------------------------------------");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;

            }
            else if (waterbtn.IsChecked == true)
            {



                paragraph.Inlines.Add("\n---------------------------------------------------\n\n Monthly Expenditure Invoice for Water and Lights\n\n" +
                                  "---------------------------------------------------\n\n" + "(Income after Tax) R " + Launch.Aftertaxincome +
        "\n\n (Water and lights amount for this month was) -R " + budget.expenses[1] + "\n\n---------------------------------------------------" +
        "\n\n (Remaining income amount after Water and lights expense) R " + budget.water + "\n\n---------------------------------------------------");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;

            }
            else if (travelbtn.IsChecked == true)
            {


                paragraph.Inlines.Add("\n---------------------------------------------------\n\nMonthly Expenditure Invoice for Travel Costs (Including Petrol) \n\n" +
                                  "---------------------------------------------------\n\n" + "(Income after Tax) R " + Launch.Aftertaxincome +
        "\n\n(Traveling Costs(Including Petrol) amount for this month was) -R " + budget.expenses[2] + "\n\n---------------------------------------------------" +
        "\n\n (Remaining income amount after Traveling Costs expense) R " + budget.travel + "\n\n---------------------------------------------------");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;


            }
            else if (cellbtn.IsChecked == true)
            {

                  

                paragraph.Inlines.Add("\n------------------------------------------------------\n\n Monthly Expenditure Invoice for Cellphone and Telphone \n\n" +
                                  "------------------------------------------------------\n\n" + "(Income after Tax) R " + Launch.Aftertaxincome +
        "\n\n(Cellphone and Tellphone amount for this month was) -R " + budget.expenses[3] + "\n\n---------------------------------------------------" +
        "\n\n(Remaining income amount after Cellphone and Tellphone expense) R " +budget.cellphone + "\n\n---------------------------------------------------");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;

            }
            else if (otherbtn.IsChecked == true)
            {

                

                paragraph.Inlines.Add("\n---------------------------------------------------\n\n Monthly Expenditure Invoice for Other\n" +
                                  "---------------------------------------------------\n\n" + "(Income after Tax) R " + Launch.Aftertaxincome +
        "\n\n(other amount for this month was) -R " + budget.expenses[4] + "\n\n---------------------------------------------------" +
        "\n\n (Remaining income amount after other expense) R " + budget.other + "\n\n---------------------------------------------------");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;

            }
            else if (allbtn.IsChecked == true)
            {
               

                paragraph.Inlines.Add("*******\n\n ~~Monthly Expenditure Invoice for all Expenses~~" +
                                  "\n\n*******\n\n" +
                        "(Income after Tax) R " + Launch.Aftertaxincome +
        "\n\n(Grocery amount for this month was) -R " + budget.expenses[0] +
        "\n\n (Water and lights amount for this month was) -R " + budget.expenses[1] +
        "\n\n (Traveling Costs(Including Petrol) amount for this month was) -R " + budget.expenses[2] +
        "\n\n (Cellphone and Tellphone amount for this month was) -R " + budget.expenses[3] +
        "\n\n (other amount for this month was) -R " + budget.expenses[4] + "\n*******" +
        "\n\n (Remaining amount after Months expenditures) R " + Math.Round(budget.expense, 2) + "\n\n*******");
                flowDocument.Blocks.Add(paragraph);
                richtextbox.Document = flowDocument;


            }
        }

        private void clearbtn(object sender, RoutedEventArgs e )
        {
            richtextbox.Document.Blocks.Clear();
           
        }

        private void richtextbox_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }
    }
}
