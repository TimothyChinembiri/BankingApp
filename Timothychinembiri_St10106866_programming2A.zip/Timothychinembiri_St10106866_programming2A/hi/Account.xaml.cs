﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    public static class Globalize
    {
        public static double incomeb, startba;

    }
    /// <summary>
    /// Interaction logic for Account.xaml
    /// </summary>
    public partial class Account : Window
    {
        public Account()
        {
            InitializeComponent();
        }
        
        //Button IN USE
        private void Button_Clicks(object sender, RoutedEventArgs e)
        {
            Globalize.startba = 0;
            Globalize.incomeb = 0;
            Check check = new Check();
            check.Show();
            this.Close();
        }

        private void Button_Clicking(object sender, RoutedEventArgs e) {
         
            saving save = new saving();
            save.remainb.Text = Globalize.startba.ToString();
            save.incomeb.Text = Globalize.incomeb.ToString();
            save.ShowDialog();
            this.Hide();


        }

        private void Button_Start(object sender, RoutedEventArgs e)
        {
            //if STATEMENT
            if(entire.IsChecked == true) {
               
                Launch launch = new Launch();
                launch.Show();
                this.Close();

            }
           
            else if (homerbtn.IsChecked == true) {

             home home = new home();
                home.Show();
                this.Close();
            

            }
          
            else if (vehiclesrbtn.IsChecked == true){ 
            
                vehicle vehicle = new vehicle();
                vehicle.Show();
                this.Close();
            }
            
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
    }
}
