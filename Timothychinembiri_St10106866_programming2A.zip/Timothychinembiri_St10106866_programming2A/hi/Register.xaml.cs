﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public static class Globals
    {
        public static String userinputname, userinputuse, userpass;
       

    }
    public partial class Register : Window
    {

        public Register()
        {
    
        InitializeComponent();
     
    }
    

        private void Done_Click(object sender, RoutedEventArgs e)
        {
        
        Globals.userinputname = Namebox.Text.ToString();
            Globals.userinputuse = Userregi.Text.ToString();
            Globals.userpass = Passwordreg.Password.ToString();

            if (checkPass(Globals.userpass, 8).Equals(true))
            {
               
                Account acc = new Account();
                acc.TextName.Text = Globals.userinputname;
                acc.Show();
                this.Close();
            }

            else if (checkPass(Globals.userpass, 8).Equals(false))
            {
                MessageBox.Show("Kindly enter a password with a Number,Lowercase, Uppercase and Special Character and minimum of 8 letters");
                Namebox.Clear();
                 Userregi.Clear();
                 Passwordreg.Clear();
            }
            }
                static bool checkPass(string pass, int mini)
                {
                    mini = 8;
                    bool hasNum = false;
                    bool hasCap = false;
                    bool hasLow = false;
                    bool hasSpec = false;
                    char curr;
                    //if statement
                    if (!(Globals.userpass.Length >= mini))
                    {
                        return false;

                    }
                    //for loop
                    for (int i = 0; i < Globals.userpass.Length; i++)
                    {
                        curr = Globals.userpass[i];
                        if (char.IsDigit(curr))
                        {
                            hasNum = true;
                        }
                        else if (char.IsUpper(curr))
                        {
                            hasCap = true;
                        }
                        else if (char.IsLower(curr))
                        {
                            hasLow = true;
                        }
                        else if (char.IsLetterOrDigit(curr))
                        {
                            hasSpec = true;
                        }
                        if (hasNum && hasCap && hasLow && hasSpec)
                        {
                            return true;
                        }

                    }
                    return true;
                }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
    }
        }
    

