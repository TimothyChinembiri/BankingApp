﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for budget.xaml
    /// </summary>
    public partial class budget : Window
    {
        public budget()
        {
            InitializeComponent();
        }
        public static Dictionary<double, string> dic_ = new Dictionary<double, string>();

         public static List<double> expenses = new List<double>(5);
		public static double groceries, water, travel, cellphone, other,after, expense;

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {

			if((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
				DragMove();
            }
        }

        private void resetbtn(object sender, RoutedEventArgs e)
        {
			groceriesblock.Clear();
			cellblock.Clear();
			otherblock.Clear();
			waterblock.Clear();
			travelblock.Clear();
		}

        private void nextbudget(object sender, RoutedEventArgs e)
        {
			
            string gro = groceriesblock.Text.ToString();
			string wat = waterblock.Text.ToString();
			string tra = travelblock.Text.ToString();
			string cell = cellblock.Text.ToString();
			string oth = otherblock.Text.ToString();

			double gr = Convert.ToDouble(gro);
			//assigning variables to into arraylist;
			expenses.Add(gr);
			groceries = Launch.Aftertaxincome - expenses[0];
			dic_.Add(expenses[0], "Groceries");
			
			double wa = Convert.ToDouble(wat);
			expenses.Add(wa);
			water = Launch.Aftertaxincome - expenses[1];
			dic_.Add(expenses[1], "Water and Lights");
			
			double trav = Convert.ToDouble(tra);
			expenses.Add(trav);
			travel = Launch.Aftertaxincome - expenses[2];
			dic_.Add(expenses[2], "Travelings");
			
			double cel = Convert.ToDouble(cell);
			expenses.Add(cel);
			cellphone = Launch.Aftertaxincome - expenses[3];
			dic_.Add(expenses[3], "Cellphone and Telephone");
			
			double ot = Convert.ToDouble(oth);
			expenses.Add(ot);
			other = Launch.Aftertaxincome - expenses[4];
			dic_.Add(expenses[4], "Other");

			after = expenses[0] + expenses[1] + expenses[2] + expenses[3] + expenses[4];
			expense = Launch.Aftertaxincome - after;

			review review = new review();
			review.Show();
			this.Close();
		}

       

    }
}
