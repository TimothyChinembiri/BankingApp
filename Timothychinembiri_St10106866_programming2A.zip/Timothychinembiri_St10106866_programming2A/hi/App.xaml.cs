﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Threading;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private const int min_time = 4000;
        protected override void OnStartup(StartupEventArgs e)
        {
            Window1 window1 = new Window1();    
            window1.Show();
            Stopwatch timer = new Stopwatch();
            timer.Start();
            base.OnStartup(e);
            MainWindow main = new MainWindow(); 
            timer.Stop();
            int remaining_time = min_time - (int)timer.ElapsedMilliseconds;
            if (remaining_time > 0)
                Thread.Sleep(remaining_time);
            window1.Close();
        }
    }
}
