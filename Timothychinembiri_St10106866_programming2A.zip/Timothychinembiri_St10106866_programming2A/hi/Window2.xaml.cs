﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }
        //Document FOR RICHTEXTBOX
        public static FlowDocument flowDocument = new FlowDocument();
        public static Paragraph paragraph = new Paragraph();
        public static FlowDocument flowDocumen = new FlowDocument();
        public static Paragraph paragrap = new Paragraph();
        

        private void reclear(object sender, RoutedEventArgs e)
        {
            richtextbox4.Document.Blocks.Clear();
        }

        private void reprint(object sender, RoutedEventArgs e)
        {
            paragraph.Inlines.Add("\n\n***************************************************************\n" +
                "----------------------------------------------------------\n" +
               "~~VEHICLE PURCHSE, CONGRATS!!!!!!!!!~~\n" +
               "----------------------------------------------------------\n" +
               "***************************************************************\n"
         );
            paragraph.Inlines.Add("Congrats on your New Car" +
                "\n\t\t\t\t\t\t\t\t\tDate:" + vehicle.dateTimes +
                "\n\n\n\nVechile Model: " + vehicle.models[0] + "\n" +
                "Vechile Make: " + vehicle.makes[0] +
                "\n------------------------------------\n" +
                "Vechile Price: R" + vehicle.prices[0] + 
                "\n------------------------------------------------\n" +
         "*****************************************************\n");
            flowDocument.Blocks.Add(paragraph);
            richtextbox4.Document = flowDocument;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }

        private void generate(object sender, RoutedEventArgs e)
        {
            paragrap.Inlines.Add("\n---------------------------------------------------\n~~~~ Statement of the month of " + vehicle.dateTimes + "~~~~\n" +
                                        "---------------------------------------------------\n\n");
            //for each for reverse
            foreach (KeyValuePair<double, string> pair in budget.dic_.OrderByDescending(pair => pair.Key))
            {
                paragrap.Inlines.Add("R" + pair.Key + "-" + pair.Value + "\n");

            }
            paragrap.Inlines.Add("\n*************************************\n" +
                "Total: R" + vehicle.sumforcalulator
                + "\n*************************************");
            flowDocumen.Blocks.Add(paragrap);
            richtextbox5.Document = flowDocumen;
        }

        private void generatebtn(object sender, RoutedEventArgs e)
        {
           futuredisplay futuredisplay = new futuredisplay();
            futuredisplay.Show();
            this.Close();
        }
    }
    }

