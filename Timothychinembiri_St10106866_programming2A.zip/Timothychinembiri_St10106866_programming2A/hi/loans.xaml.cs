﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalP
{
    /// <summary>
    /// Interaction logic for loans.xaml
    /// </summary>
    public partial class loans : Window
    {
        public loans()
        {
            InitializeComponent();
        }

        private void buyingbtn(object sender, RoutedEventArgs e)
        {
            home home = new home();
            home.balan.Text = Convert.ToString(budget.expense);
            home.Show();
            this.Close();
        }

        private void rentbtn(object sender, RoutedEventArgs e)
        {
           rent rent = new rent();
            rent.bala.Text = Convert.ToString(budget.expense);

            rent.Show();
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((e.LeftButton == MouseButtonState.Pressed) || (e.RightButton == MouseButtonState.Pressed))
            {
                DragMove();
            }
        }
    }
}
